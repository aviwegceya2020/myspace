import React from 'react'

export default function About() {
    return (
        <div>
            <section className="section about-section">
                <h1 className="section-title">about us</h1>
                <p>
                    As My Space we live to bring you the
                    best property management platform at
                    your finger tips. Giving you the
                    ability to keep track of your space
                    at all times just by click of a
                    button any where and anytime.
      </p>
            </section>

        </div>
    );
}
