import React from 'react'
import Hero from "../../components/Hero"

export default function Contact() {
    return (
        <div>
            <Hero>
                <p>You can find us on the following platforms</p>
            </Hero>

        </div>
    )
}
