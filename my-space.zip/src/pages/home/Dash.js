import React from 'react'
import createAccount from "../complaints/Complaint";
// import Navbar from '../../components/Navbar'
import Complaint from '../complaints/Complaint';
// import CreateAccount from "./CreateAccount";
import { Button } from 'antd'


// import { Router } from 'react-router-dom';
//import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
// import Header from '../components/Header';
import Layout from 'antd/lib/layout/layout';



function Dash() {

    return (
        <div></div>
    )
}
export default Dash;
